package lebe.testplugin;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;

/**
 * Created by Chris on 24.10.2016.
 */

public class Connector {

    private final int REPLY = 1;

    Messenger brokerMessenger = null;

    Messenger clientMessenger = null;

    private final IncomingHandler handler;
    private final HandlerThread handlerThread;
    boolean bound;
    private Context context;
    private final MainActivity act;

    public Connector(Context context, MainActivity activity) {
        this.context = context;
        handlerThread = new HandlerThread("ServiceHandlerThreadTestPlugin");    // MessageHandler läuft auf einme eigenen Thread
        handlerThread.start();
        handler = new IncomingHandler(handlerThread);
        clientMessenger = new Messenger(handler);
        act = activity;  // MainActivity wird übergeben, um Methoden aufzurufen zum Verändern/Abfragen von Daten je nach Nachricht
    }


    class IncomingHandler extends Handler {

        public IncomingHandler(HandlerThread thr) {
            super(thr.getLooper());
        }

        @Override
        public void handleMessage(Message msg){             // dieses Plugin sendet nur, diese Funktion kann erweitert werden
            switch (msg.what) {
                case REPLY:
                    break;
                    //Bundle replyBundle = msg.getData();
                   // String replyString = replyBundle.getString("reply");
                   // act.setView(replyString);

                default:
                    super.handleMessage(msg);
                    break;
            }
        }
    }

    public void sendData(){                                     //
        Bundle sendBundle = new Bundle();                       // Erstellen eines Bundles
        Message sendMessage = Message.obtain();                 // Erstellen einer neuen Nachricht
        String[] dataArray = {"name", act.getEditText()};       // Abrufen des Textes aus dem Textfeld
        sendBundle.putStringArray("key", dataArray);            // Einfügen in das Bundle und markierung mit "key"
        sendMessage.setData(sendBundle);                        // Bundle in die Nachricht einfügen
        sendMessage.what = 0;                                   // Art der Nachricht festlegen, siehe MessageBroker in LeBe
        try {
            brokerMessenger.send(sendMessage);
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    private ServiceConnection sc = new ServiceConnection() {   // Erstellen einer ServiceConnection zwischen Connector und MessagBroker
                                                               // für Zwei-Wege-Kommunikation
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {   // Binden von Plugin und LeBe
            brokerMessenger = new Messenger(service);
            bound = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {  // Bindung auflösen
            sc = null;
            bound = false;
        }
    };

    public boolean bindService() {
        Intent i = new Intent("lebe.lebeprototyp02.MessageBroker.ACTION_BIND");  // TAG zum finden des MessageBrokers
        return context.getApplicationContext().bindService(i, sc, Context.BIND_AUTO_CREATE);
    }

    public void unbindService(){
        if (bound){
            context.getApplicationContext().unbindService(sc);
            bound = false;
        }
    }

}
