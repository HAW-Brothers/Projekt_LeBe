package lebe.mockplugin;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;

/**
 * Created by Chris on 24.10.2016.
 */

public class Connector {

    private final int REPLY = 0;            // code für Antwortnachricht

    Messenger brokerMessenger = null;

    Messenger clientMessenger = null;

    private final IncomingHandler handler;
    private final HandlerThread handlerThread;
    boolean bound;
    private Context context;
    private final MainActivity act;

    public Connector(Context context, MainActivity activity) {
        this.context = context;
        handlerThread = new HandlerThread("ServiceHandlerThreadTestPlugin");    // MessageHandler läuft auf einme eigenen Thread
        handlerThread.start();
        handler = new IncomingHandler(handlerThread);
        clientMessenger = new Messenger(handler);
        act = activity;  // MainActivity wird übergeben, um Methoden aufzurufen zum Verändern/Abfragen von Daten je nach Nachricht
    }


    class IncomingHandler extends Handler {

        public IncomingHandler(HandlerThread thr) {
            super(thr.getLooper());
        }

        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case REPLY:
                    Bundle replyBundle = msg.getData();                     // Daten werden aus der nachricht entpackt
                    String replyString = replyBundle.getString("reply");    // String aus dem mit der Markierung "reply" wird extrahiert
                    act.addString(replyString);                             // Antwortstring wird dem Stringarray in MainActivity hinzugefügt
                    break;
                default:
                    super.handleMessage(msg);
                    break;
            }
        }
    }

    public void requestUpdate() {                    // Erfragen neuer Daten vom MessagBroker
        Bundle requestBundle = new Bundle();        // Bundle erstellen
        Message requestMessage = new Message();     // Nachricht erstellen
        requestBundle.putString("key", "name");     // "key" zur Markierung, "name" als Art der geforderten Daten (Kategorie)
        requestMessage.setData(requestBundle);      // Bundle in Nachricht einfügen
        requestMessage.what = 1;                    // art der Nachricht setzen , siehe MessageBroker
        requestMessage.replyTo = clientMessenger;   // Dieses Plugin bzw. Messenger als Sender setzen
        try {
            brokerMessenger.send(requestMessage);   // Nachricht abschicken
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    private ServiceConnection sc = new ServiceConnection() {   // Erstellen einer ServiceConnection zwischen Connector und MessagBroker
        // für Zwei-Wege-Kommunikation
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {   // Binden von Plugin und LeBe
            brokerMessenger = new Messenger(service);
            bound = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {  // Bindung auflösen
            sc = null;
            bound = false;
        }
    };

    public boolean bindService() {
        Intent i = new Intent("lebe.lebeprototyp02.MessageBroker.ACTION_BIND");  // TAG zum finden des MessageBrokers
        return context.getApplicationContext().bindService(i, sc, Context.BIND_AUTO_CREATE);
    }

    public void unbindService() {
        if (bound) {
            context.getApplicationContext().unbindService(sc);
            bound = false;
        }
    }

}