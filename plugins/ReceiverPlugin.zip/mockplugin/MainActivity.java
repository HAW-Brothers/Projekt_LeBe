package lebe.mockplugin;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

import static android.R.attr.button;


public class MainActivity extends AppCompatActivity {

    public ListView lv;
    private Button b_receive;
    private Button b_update;
    private List<String> list;
    public ArrayAdapter<String> arrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lv = (ListView) findViewById(R.id.listview);
        b_receive = (Button) findViewById(R.id.b1);
        b_update = (Button) findViewById(R.id.b2);

        list = new ArrayList<>();
        arrayAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_list_item_1, list
        );
        lv.setAdapter(arrayAdapter);

        final Connector connector = new Connector(this.getApplicationContext(), this);  //Connector initialisieren
        connector.bindService();                                                        // Aufrufen der Bindungsmethode

        b_receive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            connector.requestUpdate();
            }
        });

        b_update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                arrayAdapter.notifyDataSetChanged();
            }
        });
    }

    public void addString (String str){
        list.add(str);
    }
}

